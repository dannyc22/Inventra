from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Proveedor(models.Model):
    nombre = models.CharField(max_length=100)
    fecha_pedido = models.DateField()
    valor_pedido = models.DecimalField(max_digits=10, decimal_places=2)
    cantidad_producto = models.PositiveIntegerField()
    empresa = models.CharField(max_length=100)
    correo = models.EmailField()
    telefono = models.CharField(max_length=15)

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.IntegerField()
    fecha_agregado = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.nombre

# models.py

from django.db import models

class Cliente(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    address = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.first_name} {self.last_name}'
