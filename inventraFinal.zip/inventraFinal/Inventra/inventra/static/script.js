// Array para almacenar los clientes
let clients = [];

// Función para actualizar la tabla de clientes
function updateClientTable() {
    const tbody = document.querySelector('#client-table tbody');
    tbody.innerHTML = ''; // Limpiar la tabla

    clients.forEach((client, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.firstName}</td>
            <td>${client.lastName}</td>
            <td>${client.email}</td>
            <td>${client.phone}</td>
            <td>${client.address}</td>
            <td>
                <button class="edit" onclick="editClient(${index})">Editar</button>
                <button class="delete" onclick="deleteClient(${index})">Eliminar</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Función para agregar un nuevo cliente
function handleSubmit(event) {
    event.preventDefault(); // Evitar el comportamiento por defecto del formulario

    const id = document.querySelector('#client-id').value;
    const firstName = document.querySelector('#first-name').value;
    const lastName = document.querySelector('#last-name').value;
    const email = document.querySelector('#email').value;
    const phone = document.querySelector('#phone').value;
    const address = document.querySelector('#address').value;

    if (id) {
        // Editar cliente
        clients[id] = { firstName, lastName, email, phone, address };
    } else {
        // Agregar nuevo cliente
        clients.push({ firstName, lastName, email, phone, address });
    }

    // Limpiar el formulario y actualizar la tabla
    document.querySelector('#client-form').reset();
    document.querySelector('#client-id').value = '';
    updateClientTable();
}

// Función para editar un cliente
function editClient(index) {
    const client = clients[index];

    document.querySelector('#form-title').textContent = 'Editar Cliente';
    document.querySelector('#client-id').value = index;
    document.querySelector('#first-name').value = client.firstName;
    document.querySelector('#last-name').value = client.lastName;
    document.querySelector('#email').value = client.email;
    document.querySelector('#phone').value = client.phone;
    document.querySelector('#address').value = client.address;
}

// Función para eliminar un cliente
function deleteClient(index) {
    if (confirm('¿Estás seguro de que quieres eliminar este cliente?')) {
        clients.splice(index, 1);
        updateClientTable();
    }
}

// Inicializar la tabla con los datos actuales
updateClientTable();
