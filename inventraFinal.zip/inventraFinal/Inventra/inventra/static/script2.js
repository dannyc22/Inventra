document.addEventListener("DOMContentLoaded", () => {
    // Referencias a elementos
    const providerForm = document.getElementById("provider-form");
    const providerTable = document.getElementById("provider-table").getElementsByTagName('tbody')[0];
    const submitButton = document.getElementById("submit-btn");

    let providers = []; // Array para almacenar los proveedores

    // Función para actualizar la tabla de proveedores
    function updateTable() {
        providerTable.innerHTML = ''; // Limpiar la tabla

        providers.forEach((provider, index) => {
            const row = providerTable.insertRow();

            row.innerHTML = `
                <td>${provider.name}</td>
                <td>${provider.orderDate}</td>
                <td>${provider.orderValue}</td>
                <td>${provider.productQuantity}</td>
                <td>${provider.company}</td>
                <td>${provider.email}</td>
                <td>${provider.phone}</td>
                <td class="actions">
                    <button onclick="editProvider(${index})">Editar</button>
                    <button onclick="deleteProvider(${index})">Eliminar</button>
                </td>
            `;
        });
    }

    // Función para agregar o editar proveedor
    providerForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const provider = {
            name: document.getElementById("provider-name").value,
            orderDate: document.getElementById("order-date").value,
            orderValue: parseFloat(document.getElementById("order-value").value),
            productQuantity: parseInt(document.getElementById("product-quantity").value),
            company: document.getElementById("company").value,
            email: document.getElementById("email").value,
            phone: document.getElementById("phone").value,
        };

        const providerId = document.getElementById("provider-id").value;

        if (providerId) {
            // Editar proveedor
            providers[providerId] = provider;
        } else {
            // Agregar proveedor
            providers.push(provider);
        }

        // Limpiar formulario
        providerForm.reset();
        document.getElementById("provider-id").value = '';
        submitButton.textContent = "Guardar Proveedor";

        // Actualizar la tabla
        updateTable();
    });

    // Función para editar un proveedor
    window.editProvider = (index) => {
        const provider = providers[index];
        document.getElementById("provider-name").value = provider.name;
        document.getElementById("order-date").value = provider.orderDate;
        document.getElementById("order-value").value = provider.orderValue;
        document.getElementById("product-quantity").value = provider.productQuantity;
        document.getElementById("company").value = provider.company;
        document.getElementById("email").value = provider.email;
        document.getElementById("phone").value = provider.phone;

        // Cambiar texto del botón a "Actualizar"
        submitButton.textContent = "Actualizar Proveedor";
        document.getElementById("provider-id").value = index;
    };

    // Función para eliminar un proveedor
    window.deleteProvider = (index) => {
        if (confirm("¿Estás seguro de que deseas eliminar este proveedor?")) {
            providers.splice(index, 1); // Eliminar proveedor del array
            updateTable(); // Actualizar la tabla
        }
    };
});
