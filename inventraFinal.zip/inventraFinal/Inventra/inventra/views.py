from django.shortcuts import render, get_object_or_404, redirect
from .models import Producto, Proveedor
from django.db.models import Q


def listar_productos(request):
    query = request.GET.get('q')
    if query:
        productos = Producto.objects.filter(
            Q(nombre__icontains=query) | Q(descripcion__icontains=query)
        )
    else:
        productos = Producto.objects.all()
    return render(request, 'listar_productos.html', {'productos': productos})

def crear_producto(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        descripcion = request.POST['descripcion']
        precio = request.POST['precio']
        stock = request.POST['stock']
        Producto.objects.create(
            nombre=nombre, descripcion=descripcion, precio=precio, stock=stock
        )
        return redirect('listar_productos')
    return render(request, 'crear_producto.html')
def actualizar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    if request.method == 'POST':
        producto.nombre = request.POST['nombre']
        producto.descripcion = request.POST['descripcion']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.save()
        return redirect('listar_productos')
    return render(request, 'actualizar_producto.html', {'producto': producto})

def eliminar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    producto.delete()
    return redirect('listar_productos')


def index(request):
    return render(request, 'Index.html')

def dashboard(request):
    return render(request, 'dashboard.html')  

def clientes(request):
    return render(request, 'clientes.html')

# Vista para la página de proveedores
def proveedores(request):
    return render(request, 'proveedores.html')

# Vista para la página de productos
def productos(request):
    return render(request, 'productos.html')

# Vista para la página de ventas
def ventas(request):
    return render(request, 'ventas.html')


def proveedores(request):
    proveedores = Proveedor.objects.all()  # Trae todos los proveedores de la base de datos
    return render(request, 'proveedores.html', {'proveedores': proveedores})    
